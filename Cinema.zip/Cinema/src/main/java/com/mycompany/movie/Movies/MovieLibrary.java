package com.mycompany.movie.Movies;

import com.mycompany.movie.Database;
import java.text.ParseException;
import java.util.List;

public class MovieLibrary {
    private static List<Movie> movies;

    public MovieLibrary(List<Movie> movies) {
        MovieLibrary.movies = movies;
    }

    public static boolean addMovie (Movie movie) throws ParseException {
        Database.addMovieWithScreenTimes(movie);
        return movies.add(movie);
    }

    public static boolean deleteMovie (Movie movie){
        
        Database.deleteMovie(movie.getID());
        return movies.remove(movie);
    }

    public static boolean hasMovie(Movie movie) {
        return movies.contains(movie);
    }

    public static List<Movie> getMovies () {
        movies= Database.listMoviesWithScreenTimes();
        
        return movies;
    }

}
