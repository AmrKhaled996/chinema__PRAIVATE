/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.movie;

import java.util.Scanner;
import com.mycompany.movie.GUI.*;

/**
 *
 * @author MU
 */
public class Movie {
    public static void main (String[] args) {
//        Scanner scanObj = new Scanner(System.in);
//        CLI.Manager cli = new CLI.Manager(scanObj);
//        cli.start(scanObj);
//        new MyFrame();
    }
}
